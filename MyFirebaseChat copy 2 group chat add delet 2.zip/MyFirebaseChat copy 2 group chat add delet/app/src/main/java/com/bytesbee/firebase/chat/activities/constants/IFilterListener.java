package com.bytesbee.firebase.chat.activities.constants;

public interface IFilterListener {
    void showFilterUsers();

}
