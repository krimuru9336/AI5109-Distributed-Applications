package com.bytesbee.firebase.chat.activities.constants;

public interface IDialogListener {
    void yesButton();
}
