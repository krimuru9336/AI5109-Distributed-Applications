package com.bytesbee.firebase.chat.activities.fcmmodels;

public class MyResponse {
    public int success;
}
