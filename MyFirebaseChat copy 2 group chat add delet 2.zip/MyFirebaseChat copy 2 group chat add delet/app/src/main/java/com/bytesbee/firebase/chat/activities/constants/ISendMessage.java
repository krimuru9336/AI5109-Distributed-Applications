package com.bytesbee.firebase.chat.activities.constants;

public interface ISendMessage {
    void sendSetting(String value);
}
