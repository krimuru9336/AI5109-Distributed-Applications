package com.devlomi.record_view;

public interface RecordPermissionHandler {
    boolean isPermissionGranted();
}
